import warnings
warnings.warn(
'''Use

from mahotas.features import tas
''', DeprecationWarning)

from mahotas.features.tas import *
